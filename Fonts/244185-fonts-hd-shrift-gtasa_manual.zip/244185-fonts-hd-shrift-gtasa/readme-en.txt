Fonts HD Шрифт
-------------------------------------------------------------
Качественный шрифт максимально схожий с оригиналом.
Подходит для оригинальной и русских версий:
SanLTD и потраченный!

Примечание:
У SanLTD хороший шрифт, но не достаточно схож с оригиналом. И font2 менее качественный.

Обновление:
- отточены интервалы
- добавлены вариации шрифта Pricedown (название миссий и т. п.) для букв Т, М, Д.
-------------------------------------------------------------
Installation instructions:
-------------------------------------------------------------
1) Author: DimZet
Was added to the site by user: lk_1997_kl
-------------------------------------------------------------
2) Copying files:
All contents of the folder "To copy to game folder" copy into the game folder confirming the replacement.

(!) If You wish to be able to remove a modification, make sure You save original copies of the replaced files safely.
-------------------------------------------------------------
This modification was downloaded from https://GameModding.com/ website
Follow us in social networks!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
