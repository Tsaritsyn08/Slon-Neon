Fonts HD Шрифт
-------------------------------------------------------------
Качественный шрифт максимально схожий с оригиналом.
Подходит для оригинальной и русских версий:
SanLTD и потраченный!

Примечание:
У SanLTD хороший шрифт, но не достаточно схож с оригиналом. И font2 менее качественный.

Обновление:
- отточены интервалы
- добавлены вариации шрифта Pricedown (название миссий и т. п.) для букв Т, М, Д.
-------------------------------------------------------------
Installation Anleitung:
-------------------------------------------------------------
1) Der Autor: DimZet
Auf der Site vom Benutzer hinzugefuegt wurde: lk_1997_kl
-------------------------------------------------------------
2) Kopieren von Dateien:
Alle Inhalte des Ordners "To copy to game folder" Kopieren Sie in den Spiel-Ordner den Ersatz bestaetigt.

(!) Wenn Sie in der Lage sein, die Aenderung zu entfernen, stellen Sie sicher, dass Sie die Original-Kopien ersetzten Dateien an einem sicheren Ort erhalten.
-------------------------------------------------------------
Diese Modifikation wurde von der Website https://GameModding.com/en/ heruntergeladen\r\nFolgen Sie uns in den sozialen Netzwerken!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
